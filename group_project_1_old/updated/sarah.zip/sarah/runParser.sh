python skeleton_parser.py ebay_data/items-*.json
