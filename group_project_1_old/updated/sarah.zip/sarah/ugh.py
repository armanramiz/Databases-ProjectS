string="skeleton_parser.py"
for i in range(40):
    string+=" ebay_data/items-"+str(i)+".json"
print(string)
